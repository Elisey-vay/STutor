# SUPER_REPETITOR — network test

This package adds a small Node.js server so the same teacher/student data can be shared between two phones.

## Render
1. Upload this folder to a GitHub repository.
2. On Render create a **Web Service** from that repository.
3. Build Command: leave empty.
4. Start Command: `node server.js`
5. After deploy, open the generated `https://...onrender.com` URL.
6. On both phones open `SUPER_repetitor.html` and press **☁️ Сеть**.
7. Enter the same Render URL and press **Сохранить и проверить**.

The HTML keeps localStorage as a fallback, but when a server URL is configured it synchronizes the state with the server.

This is a TEST server. It does not implement production-grade authentication/encryption for the stored state. Do not use it for real private student data until proper authentication and access control are added.
