const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = Number(process.env.PORT || 10000);
const DATA_FILE = path.join(__dirname, 'data.json');
const INDEX_FILE = path.join(__dirname, 'public', 'SUPER_repetitor.html');
const MAX_BODY = 20 * 1024 * 1024;

const DEFAULT = {
  users: [],
  messages: {},
  theme: 'blue',
  teacher: { login: 'mama.repetitor', pass: 'SuperMath2026!', name: 'Елена', role: 'teacher', theme: 'blue' }
};

let version = 1;
let state = loadState();

function loadState() {
  try {
    if (fs.existsSync(DATA_FILE)) return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch (_) {}
  return structuredClone(DEFAULT);
}
function saveState() {
  const tmp = DATA_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(state));
  fs.renameSync(tmp, DATA_FILE);
  version++;
}
function send(res, code, body, type='application/json') {
  const data = Buffer.from(typeof body === 'string' ? body : JSON.stringify(body));
  res.writeHead(code, {
    'Content-Type': type + '; charset=utf-8',
    'Content-Length': data.length,
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET,PUT,OPTIONS',
    'Cache-Control': 'no-store'
  });
  res.end(data);
}
function readJson(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', chunk => {
      size += chunk.length;
      if (size > MAX_BODY) { reject(new Error('too-large')); req.destroy(); return; }
      chunks.push(chunk);
    });
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
      catch (_) { reject(new Error('bad-json')); }
    });
    req.on('error', reject);
  });
}
function validState(x) {
  return x && typeof x === 'object' && x.teacher && typeof x.teacher === 'object' &&
    Array.isArray(x.users) && x.messages && typeof x.messages === 'object' && !Array.isArray(x.messages);
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204, '');

  if (req.method === 'GET' && req.url === '/health') {
    return send(res, 200, { ok: true, service: 'SUPER_REPETITOR', version });
  }

  if (req.method === 'GET' && req.url.startsWith('/api/state')) {
    return send(res, 200, { ...state, _version: version });
  }

  if (req.method === 'PUT' && req.url === '/api/state') {
    try {
      const incoming = await readJson(req);
      if (!validState(incoming)) return send(res, 400, { ok: false, error: 'invalid_state' });
      delete incoming._version;
      state = incoming;
      saveState();
      return send(res, 200, { ok: true, version });
    } catch (e) {
      return send(res, e.message === 'too-large' ? 413 : 400, { ok: false, error: e.message });
    }
  }

  if (req.method === 'GET' && (req.url === '/' || req.url === '/index.html')) {
    try { return send(res, 200, fs.readFileSync(INDEX_FILE), 'text/html'); }
    catch (_) { return send(res, 500, 'Server file missing', 'text/plain'); }
  }

  return send(res, 404, { ok: false, error: 'not_found' });
});

server.listen(PORT, '0.0.0.0', () => console.log(`SUPER_REPETITOR server listening on ${PORT}`));
